/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package khanbanboard;

import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class KhanBanBoard {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // Create an instance of the KhanBan class
KhanBan objKhanBan = new KhanBan();

while (true) {
    // Define the menu options
    String menu = "Choose Option:\n1. Add Tasks\n2. Show Tasks Done\n3. Show Longest Task Duration\n4. Search Task by Name\n5. Search Tasks by Developer\n6. Delete Task by Name\n7. Show Report\n8. Quit";
    
    // Show the menu and get the user's choice
    String choiceStr = JOptionPane.showInputDialog(null, menu, "KhanBan", JOptionPane.INFORMATION_MESSAGE);

    // If the user cancels the input dialog, exit the application
    if (choiceStr == null) {
        JOptionPane.showMessageDialog(null, "Exiting Application", "KhanBan", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }

    try {
        // Convert the user's choice to an integer
        int choice = Integer.parseInt(choiceStr);

        // Handle the user's choice
        switch (choice) {
            case 1:
                // Add a new task
                objKhanBan.AddTask();
                break;
            case 2:
                // Display tasks marked as done
                objKhanBan.displayTaskWithDone();
                break;
            case 3:
                // Display the task with the longest duration
                objKhanBan.displayTaskWithLongestDuration();
                break;
            case 4:
                // Prompt the user to enter a task name to search for
                String taskNameSearch = JOptionPane.showInputDialog("Enter task name to search");
                objKhanBan.SearchTaskByTaskName(taskNameSearch);
                break;
            case 5:
                // Prompt the user to enter a developer's name to search for tasks assigned to them
                String developerSearch = JOptionPane.showInputDialog("Enter Developer Name to search");
                objKhanBan.SearchTaskByDeveloper(developerSearch);
                break;
            case 6:
                // Prompt the user to enter a task name to delete
                String taskNameDelete = JOptionPane.showInputDialog("Enter Task Name to Delete");
                objKhanBan.deleteTaskByName(taskNameDelete);
                break;
            case 7:
                // Display a report of tasks
                objKhanBan.displayReport();
                break;
            case 8:
                // Show the total duration of all tasks and exit the application
                JOptionPane.showMessageDialog(null, "Total Task Duration: " + KhanBan.getTotalTaskDuration() + " hours", "KhanBan", JOptionPane.INFORMATION_MESSAGE);
                JOptionPane.showMessageDialog(null, "Exiting Application", "KhanBan", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
                break;
            default:
                // Handle invalid menu options
                JOptionPane.showMessageDialog(null, "Invalid Option", "KhanBan", JOptionPane.INFORMATION_MESSAGE);
                break;
        }

    } catch (NumberFormatException e) {
        // Handle invalid input format (non-integer values)
        JOptionPane.showMessageDialog(null, "Invalid Option Format", "KhanBan", JOptionPane.INFORMATION_MESSAGE);
    }
}
    }
}