/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package khanbanboard;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class KhanBanTest {
    
    public KhanBanTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of AddTask method, of class KhanBan.
     */
    @Test
    public void testAddTask() {
        System.out.println("AddTask");
        KhanBan instance = new KhanBan();
        instance.AddTask();
       
    }

    /**
     * Test of Display method, of class KhanBan.
     */
    @Test
    public void testDisplay() {
        System.out.println("Display");
        String taskName = "";
        int taskNum = 0;
        String taskDescription = "";
        String developerDetails = "";
        int taskDuration = 0;
        String taskStatus = "";
        KhanBan instance = new KhanBan();
        instance.Display(taskName, taskNum, taskDescription, developerDetails, taskDuration, taskStatus);
      
    }

    /**
     * Test of displayTaskWithDone method, of class KhanBan.
     */
    @Test
    public void testDisplayTaskWithDone() {
        System.out.println("displayTaskWithDone");
        KhanBan instance = new KhanBan();
        instance.displayTaskWithDone();
     
    }

    /**
     * Test of displaTaskWithLongestDuration method, of class KhanBan.
     */
    @Test
    public void testDisplaTaskWithLongestDuration() {
        System.out.println("displaTaskWithLongestDuration");
        KhanBan instance = new KhanBan();
        instance.displayTaskWithLongestDuration();
      
    }

    /**
     * Test of SearchTaskByDeveloper method, of class KhanBan.
     */
    @Test
    public void testSearchTaskByDeveloper() {
        System.out.println("SearchTaskByDeveloper");
        String developer = "";
        KhanBan instance = new KhanBan();
        instance.SearchTaskByDeveloper(developer);
        
    }

    /**
     * Test of SearchTaskByTaskName method, of class KhanBan.
     */
    @Test
    public void testSearchTaskByTaskName() {
        System.out.println("SearchTaskByTaskName");
        String taskName = "";
        KhanBan instance = new KhanBan();
        instance.SearchTaskByTaskName(taskName);
  
    }

    /**
     * Test of deleteTaskByName method, of class KhanBan.
     */
    @Test
    public void testDeleteTaskByName() {
        System.out.println("deleteTaskByName");
        String TaskName = "";
        KhanBan instance = new KhanBan();
        instance.deleteTaskByName(TaskName);
    
    }

    /**
     * Test of displayReport method, of class KhanBan.
     */
    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        KhanBan instance = new KhanBan();
        instance.displayReport();
     
    }

    /**
     * Test of getTotalTaskDuration method, of class KhanBan.
     */
    @Test
    public void testGetTotalTaskDuration() {
        System.out.println("getTotalTaskDuration");
        int expResult = 0;
        int result = KhanBan.getTotalTaskDuration();
        assertEquals(expResult, result);
      
    }
    
}
